package com.berkemc11.hugoauction;

import net.fabricmc.api.ModInitializer;

public class HugoAuctionMod implements ModInitializer {
    public static final String MOD_ID = "hugoauction";
    public static final String SELLER = "BerkeMC11";

    @Override
    public void onInitialize() {
        // The auction helper UI is client-side because HugoSMP's private server
        // does not expose a server-side mod/plugin API to this project.
    }
}
