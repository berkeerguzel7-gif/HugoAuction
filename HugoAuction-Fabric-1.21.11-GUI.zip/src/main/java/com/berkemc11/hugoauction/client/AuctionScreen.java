package com.berkemc11.hugoauction.client;

import com.berkemc11.hugoauction.HugoAuctionMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class AuctionScreen extends Screen {
    private TextFieldWidget amount;

    public AuctionScreen(Text title) {
        super(title);
    }

    @Override
    protected void init() {
        int left = (this.width - 360) / 2;
        int top = (this.height - 210) / 2;

        amount = new TextFieldWidget(this.textRenderer, left + 120, top + 136, 110, 20, Text.literal("Betrag"));
        amount.setText("100");
        amount.setChangedListener(value -> {
            if (!value.matches("\\d*")) amount.setText(value.replaceAll("[^0-9]", ""));
        });
        this.addDrawableChild(amount);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Bieten /pay"), button -> pay())
                .dimensions(left + 238, top + 136, 110, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Schließen"), button -> close())
                .dimensions(left + 120, top + 166, 110, 20).build());
    }

    private void pay() {
        String value = amount.getText();
        if (value.isBlank() || value.equals("0")) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.networkHandler.sendChatCommand("pay " + HugoAuctionMod.SELLER + " " + value);
            client.player.sendMessage(Text.literal("§6Hugo Auction §7→ §f/pay " + HugoAuctionMod.SELLER + " " + value), false);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        int left = (this.width - 360) / 2;
        int top = (this.height - 210) / 2;
        int right = left + 360;
        int bottom = top + 210;

        context.fill(left, top, right, bottom, 0xF0101018);
        context.fill(left + 2, top + 2, right - 2, top + 26, 0xFF242432);
        context.drawText(this.textRenderer, Text.literal("Hugo Auction"), left + 12, top + 9, 0xFFD8A83E, false);
        context.drawText(this.textRenderer, Text.literal("Made by BerkeMC11"), right - 118, top + 9, 0xFFFFFFFF, false);

        context.drawText(this.textRenderer, Text.literal("Verkäufer"), left + 20, top + 43, 0xFFAAAAAA, false);
        context.drawText(this.textRenderer, Text.literal(HugoAuctionMod.SELLER), left + 20, top + 57, 0xFFFFD966, false);

        context.fill(left + 18, top + 76, left + 98, top + 126, 0xFF181820);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("ITEM"), left + 58, top + 95, 0xFF777777);

        context.drawText(this.textRenderer, Text.literal("Aktuelles Gebot"), left + 120, top + 48, 0xFFAAAAAA, false);
        context.drawText(this.textRenderer, Text.literal("0"), left + 120, top + 64, 0xFF55FF55, false);
        context.drawText(this.textRenderer, Text.literal("Gebot eingeben"), left + 120, top + 118, 0xFFAAAAAA, false);
        context.drawText(this.textRenderer, Text.literal("/pay " + HugoAuctionMod.SELLER + " <Betrag>"), left + 20, top + 191, 0xFFBBBBBB, false);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
