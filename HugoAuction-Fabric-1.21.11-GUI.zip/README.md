# Hugo Auction — Fabric 1.21.11

Made by BerkeMC11.

## What this build does
- Opens the Hugo Auction helper GUI with `/hugoauction` or the default `K` key.
- Shows seller `BerkeMC11`.
- Lets the player enter an amount and sends the server's existing `/pay BerkeMC11 <Betrag>` command.
- Does not create a fake economy.

## Important HugoSMP limitation
The project does not have access to HugoSMP's private server plugin/mod/API. Therefore this client mod cannot independently verify payments, synchronize a real auction between all players, refund previous bids, or determine the actual highest bid. Those parts require server-side integration.
