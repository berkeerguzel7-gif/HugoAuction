@echo off
setlocal
cd /d "%~dp0"
title Hugo Auction - Build
echo ==========================================
echo Hugo Auction - automatische JAR-Erstellung
echo Made by BerkeMC11
echo ==========================================
echo.
where java >nul 2>&1
if errorlevel 1 (
  echo [FEHLER] Java wurde nicht gefunden. Bitte Java 21 installieren.
  pause
  exit /b 1
)
java -version
if not exist ".build-tools\gradle-8.10.2\bin\gradle.bat" (
  echo.
  echo Gradle wird einmalig heruntergeladen...
  if not exist ".build-tools" mkdir ".build-tools"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.10.2-bin.zip' -OutFile '.build-tools\gradle.zip'"
  if errorlevel 1 (echo [FEHLER] Download fehlgeschlagen.& pause & exit /b 1)
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '.build-tools\gradle.zip' -DestinationPath '.build-tools' -Force"
  del ".build-tools\gradle.zip"
)
echo.
echo Baue die Mod. Beim ersten Mal kann es einige Minuten dauern.
echo.
call ".build-tools\gradle-8.10.2\bin\gradle.bat" build --no-daemon
if errorlevel 1 (
  echo.
  echo [FEHLER] Build fehlgeschlagen. Schicke mir die Fehlermeldung.
  pause
  exit /b 1
)
echo.
echo ==========================================
echo FERTIG! Die JAR liegt in build\libs\
echo ==========================================
explorer "%CD%\build\libs"
pause
