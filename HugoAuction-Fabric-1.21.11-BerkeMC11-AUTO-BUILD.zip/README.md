# Hugo Auction – Minecraft 1.21.11

Made by **BerkeMC11**.

## Einfachste Methode unter Windows
1. Java 21 installieren.
2. ZIP entpacken.
3. `BAUEN.bat` doppelklicken.
4. Die fertige Mod liegt danach in `build\\libs\\`. Nimm die JAR mit dem kürzesten Namen.

Die Build-Datei nutzt Fabric Loom für Minecraft 1.21.11.

## HugoSMP
Die Mod erstellt kein eigenes Geldsystem. Die Zahlungsanzeige lautet:
`/pay BerkeMC11 <Betrag>`

Automatische Prüfung einer erfolgreichen HugoSMP-Zahlung ist ohne Server-Unterstützung nicht möglich.
