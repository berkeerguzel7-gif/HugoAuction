package com.berkemc11.hugoauction;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;

public class HugoAuctionMod implements ModInitializer {
    public static final String MOD_ID = "hugoauction";
    public static final String SELLER = "BerkeMC11";

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("hugoauction")
                .executes(ctx -> {
                    ctx.getSource().sendFeedback(
                        () -> Text.literal("§6§lHugo Auction §7- §fMade by §e" + SELLER),
                        false
                    );
                    ctx.getSource().sendFeedback(
                        () -> Text.literal("§7Zahlung: §e/pay " + SELLER + " <Betrag>"),
                        false
                    );
                    ctx.getSource().sendFeedback(
                        () -> Text.literal("§7Hinweis: Diese Mod führt kein eigenes Geldsystem."),
                        false
                    );
                    return 1;
                }));
        });
    }
}
