package de.hugosmp.auction;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class HugoAuctionMod implements ModInitializer {
    public static final Map<UUID, Double> BALANCES = new ConcurrentHashMap<>();
    public static AuctionManager AUCTIONS;

    @Override public void onInitialize() {
        AUCTIONS=new AuctionManager();
        CommandRegistrationCallback.EVENT.register((d,r,e)->AuctionCommands.register(d,AUCTIONS));
    }
    public static String money(double n){ return String.format("%,.0f",n).replace(',','.'); }
}
