package de.hugosmp.auction;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.*;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import static net.minecraft.server.command.CommandManager.*;

public class AuctionCommands {
 public static void register(CommandDispatcher<ServerCommandSource> d,AuctionManager m){
  d.register(literal("auktion").then(literal("start")
   .then(argument("mindestgebot",DoubleArgumentType.doubleArg(.01))
   .then(argument("sekunden",IntegerArgumentType.integer(10,3600)).executes(c->{
    ServerPlayerEntity p=c.getSource().getPlayer();
    double b=DoubleArgumentType.getDouble(c,"mindestgebot"); int s=IntegerArgumentType.getInteger(c,"sekunden");
    if(m.create(p,b,s)){p.sendMessage(Text.literal("§aAuktion gestartet!"));return 1;}
    p.sendMessage(Text.literal("§cEs läuft bereits eine Auktion oder du hältst kein Item."));return 0;
   })))));
  d.register(literal("pay").then(argument("spieler",StringArgumentType.word())
   .then(argument("betrag",DoubleArgumentType.doubleArg(.01)).executes(c->{
    ServerPlayerEntity p=c.getSource().getPlayer();
    String target=StringArgumentType.getString(c,"spieler"); double amount=DoubleArgumentType.getDouble(c,"betrag");
    Auction a=m.getAuction();
    if(a!=null&&target.equalsIgnoreCase(a.sellerName)){
      if(m.placeBid(p,amount))p.sendMessage(Text.literal("§aGebot angenommen: $"+HugoAuctionMod.money(amount)));
      else p.sendMessage(Text.literal("§cGebot abgelehnt."));
      return 1;
    }
    p.sendMessage(Text.literal("§cFür diesen Spieler läuft keine Auktion."));return 0;
   }))));
 }
}
