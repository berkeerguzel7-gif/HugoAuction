package de.hugosmp.auction;
import net.minecraft.item.ItemStack;
import java.util.UUID;

public class Auction {
    public final UUID seller; public final String sellerName; public final ItemStack item;
    public final double startingBid; public final long endAt;
    public double highestBid; public UUID highestBidder; public String highestBidderName;
    public Auction(UUID s,String sn,ItemStack i,double b,long e){
        seller=s;sellerName=sn;item=i.copy();startingBid=b;highestBid=b;endAt=e;
    }
}
