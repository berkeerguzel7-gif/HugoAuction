package de.hugosmp.auction;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;

public class AuctionManager {
    private Auction auction;
    public Auction getAuction(){return auction;}

    public boolean create(ServerPlayerEntity p,double start,int seconds){
        if(auction!=null)return false;
        ItemStack hand=p.getMainHandStack();
        if(hand.isEmpty())return false;
        ItemStack item=hand.copy();
        p.setStackInHand(Hand.MAIN_HAND,ItemStack.EMPTY);
        auction=new Auction(p.getUuid(),p.getName().getString(),item,start,System.currentTimeMillis()+seconds*1000L);
        broadcast(p.getServer(),Text.literal("§6§l🔨 NEUE AUKTION"));
        broadcast(p.getServer(),Text.literal("§e"+p.getName().getString()+" §7versteigert §f"+item.getCount()+"x "+item.getItem().toString()+" §7| Mindestgebot: §a$"+HugoAuctionMod.money(start)));
        broadcast(p.getServer(),Text.literal("§bBieten: §f/pay "+p.getName().getString()+" <Betrag>"));
        startTicker(p.getServer());
        return true;
    }

    public boolean placeBid(ServerPlayerEntity p,double amount){
        if(auction==null||p.getUuid().equals(auction.seller)||amount<=auction.highestBid)return false;
        double bal=HugoAuctionMod.BALANCES.getOrDefault(p.getUuid(),0.0);
        if(bal<amount)return false;
        HugoAuctionMod.BALANCES.put(p.getUuid(),bal-amount);
        // Frühere Gebote werden NICHT zurückerstattet.
        // Jedes neue Gebot bleibt beim Server/Verkäufer und erhöht das Höchstgebot.
        auction.highestBid=amount; auction.highestBidder=p.getUuid(); auction.highestBidderName=p.getName().getString();
        broadcast(p.getServer(),Text.literal("§a§l💰 NEUES HÖCHSTGEBOT"));
        broadcast(p.getServer(),Text.literal("§eBieter: §f"+auction.highestBidderName+" §7| §eHöchstgebot: §a$"+HugoAuctionMod.money(amount)));
        broadcast(p.getServer(),Text.literal("§bWeiterbieten: §f/pay "+auction.sellerName+" <Betrag>"));
        return true;
    }

    private void startTicker(MinecraftServer server){
        new Thread(()->{
            while(server.isRunning()){
                try{Thread.sleep(1000);}catch(InterruptedException e){return;}
                if(auction!=null&&System.currentTimeMillis()>=auction.endAt)server.execute(()->finish(server));
            }
        },"HugoAuction-Ticker").start();
    }

    private void finish(MinecraftServer server){
        if(auction==null)return; Auction a=auction; auction=null;
        if(a.highestBidder==null){
            ServerPlayerEntity s=server.getPlayerManager().getPlayer(a.seller);
            if(s!=null)s.getInventory().offerOrDrop(a.item.copy());
            broadcast(server,Text.literal("§cAuktion beendet – niemand hat geboten.")); return;
        }
        HugoAuctionMod.BALANCES.merge(a.seller,a.highestBid,Double::sum);
        ServerPlayerEntity w=server.getPlayerManager().getPlayer(a.highestBidder);
        if(w!=null)w.getInventory().offerOrDrop(a.item.copy());
        broadcast(server,Text.literal("§6§l🏆 AUKTION BEENDET §r§6| Gewinner: §e"+a.highestBidderName+" §7| §a$"+HugoAuctionMod.money(a.highestBid)));
    }
    private void broadcast(MinecraftServer s,Text t){s.getPlayerManager().broadcast(t,false);}
}
